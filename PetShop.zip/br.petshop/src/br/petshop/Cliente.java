package br.petshop;

public class Cliente extends Pessoa {
    private Animal animal;

    public Cliente(String nome, Animal animal) {
        super(nome);
        this.animal = animal;
    }

    public Animal getAnimal() {
        return animal;
    }

    public void setAnimal(Animal animal) {
        this.animal = animal;
    }

    @Override
    public void exibirInfo() {
        System.out.println("Cliente: " + nome + " | Animal: " + animal.getNome() + " (" + animal.getTipo() + ")");
    }
}
