package br.petshop;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PetShop petshop = new PetShop();

        // --- Dados iniciais fictícios ---
        petshop.cadastrarFuncionario(new Funcionario("Mariana", "Atendente"));
        petshop.cadastrarFuncionario(new Funcionario("Roberto", "Tosador"));
        petshop.cadastrarFuncionario(new Funcionario("Luciana", "Veterinária"));

        petshop.cadastrarRacao(new Racao("Ração Premium Cães Adultos", 25.0));
        petshop.cadastrarRacao(new Racao("Ração Whiskas Gatos", 18.5));
        petshop.cadastrarRacao(new Racao("Ração Golden Filhotes", 30.0));

        petshop.adicionarServico(new Servico("Banho", 50));
        petshop.adicionarServico(new Servico("Tosa", 60));
        petshop.adicionarServico(new Servico("Banho e Tosa", 100));

        int opcao;
        do {
            System.out.println("\n===== PET SHOP MENU =====");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Cadastrar Funcionário");
            System.out.println("3. Cadastrar Ração");
            System.out.println("4. Vender Ração");
            System.out.println("5. Realizar Serviço");
            System.out.println("6. Consultas");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine(); // limpa buffer

            switch (opcao) {
                case 1:
                    System.out.print("Nome do cliente: ");
                    String nomeCliente = sc.nextLine();
                    System.out.print("Nome do animal: ");
                    String nomeAnimal = sc.nextLine();
                    System.out.print("Tipo do animal: ");
                    String tipoAnimal = sc.nextLine();
                    Cliente cliente = new Cliente(nomeCliente, new Animal(nomeAnimal, tipoAnimal));
                    petshop.cadastrarCliente(cliente);
                    break;

                case 2:
                    System.out.print("Nome do funcionário: ");
                    String nomeFunc = sc.nextLine();
                    System.out.print("Cargo: ");
                    String cargo = sc.nextLine();
                    petshop.cadastrarFuncionario(new Funcionario(nomeFunc, cargo));
                    break;

                case 3:
                    System.out.print("Nome da ração: ");
                    String nomeR = sc.nextLine();
                    System.out.print("Preço: ");
                    double preco = sc.nextDouble();
                    petshop.cadastrarRacao(new Racao(nomeR, preco));
                    break;

                case 4:
                    petshop.listarRacoes();
                    System.out.print("Escolha o número da ração: ");
                    int idxR = sc.nextInt() - 1;
                    System.out.print("Quantidade (kg): ");
                    double kg = sc.nextDouble();
                    petshop.venderRacao(idxR, kg);
                    break;

                case 5:
                    petshop.listarServicos();
                    System.out.print("Escolha o serviço: ");
                    int idxS = sc.nextInt() - 1;
                    petshop.realizarServico(idxS);
                    break;

                case 6:
                    System.out.println("\n--- CONSULTAS ---");
                    petshop.listarClientes();
                    petshop.listarFuncionarios();
                    petshop.listarRacoes();
                    break;

                case 0:
                    System.out.println("\nEncerrando o sistema...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);

        // Ao sair, mostra o relatório final:
        petshop.gerarRelatorioFinal();

        sc.close();
    }
}
