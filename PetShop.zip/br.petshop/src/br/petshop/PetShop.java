package br.petshop;

import java.util.ArrayList;

public class PetShop {
    private ArrayList<Cliente> clientes = new ArrayList<>();
    private ArrayList<Funcionario> funcionarios = new ArrayList<>();
    private ArrayList<Racao> racoes = new ArrayList<>();
    private ArrayList<Servico> servicos = new ArrayList<>();
    private ArrayList<String> historicoVendas = new ArrayList<>();

    private double totalVendas = 0.0;

    // -------- CADASTROS --------
    public void cadastrarCliente(Cliente cliente) {
        clientes.add(cliente);
        System.out.println("Cliente cadastrado com sucesso!");
    }

    public void cadastrarFuncionario(Funcionario funcionario) {
        funcionarios.add(funcionario);
        System.out.println("Funcionário cadastrado com sucesso!");
    }

    public void cadastrarRacao(Racao racao) {
        racoes.add(racao);
        System.out.println("Ração cadastrada com sucesso!");
    }

    // -------- VENDAS E SERVIÇOS --------
    public void venderRacao(int index, double quantidadeKg) {
        if (index >= 0 && index < racoes.size()) {
            Racao r = racoes.get(index);
            double total = r.getPreco() * quantidadeKg;
            totalVendas += total;
            historicoVendas.add("Venda: " + r.getNome() + " (" + quantidadeKg + "kg) - R$ " + total);
            System.out.println("Venda registrada! Total: R$ " + total);
        } else {
            System.out.println("Ração inválida!");
        }
    }

    public void realizarServico(int index) {
        if (index >= 0 && index < servicos.size()) {
            Servico s = servicos.get(index);
            totalVendas += s.getValor();
            historicoVendas.add("Serviço: " + s.getTipo() + " - R$ " + s.getValor());
            System.out.println("Serviço realizado com sucesso!");
        } else {
            System.out.println("Serviço inválido!");
        }
    }

    public void adicionarServico(Servico servico) {
        servicos.add(servico);
    }

    // -------- CONSULTAS --------
    public void listarClientes() {
        System.out.println("\n--- CLIENTES ---");
        for (Cliente c : clientes) c.exibirInfo();
    }

    public void listarFuncionarios() {
        System.out.println("\n--- FUNCIONÁRIOS ---");
        for (Funcionario f : funcionarios) f.exibirInfo();
    }

    public void listarRacoes() {
        System.out.println("\n--- RAÇÕES ---");
        for (int i = 0; i < racoes.size(); i++) {
            System.out.println((i + 1) + ". " + racoes.get(i));
        }
    }

    public void listarServicos() {
        System.out.println("\n--- SERVIÇOS ---");
        for (int i = 0; i < servicos.size(); i++) {
            System.out.println((i + 1) + ". " + servicos.get(i));
        }
    }

    // -------- RELATÓRIO FINAL --------
    public void gerarRelatorioFinal() {
        System.out.println("\n========== RELATÓRIO FINAL ==========");
        listarClientes();
        listarFuncionarios();
        listarRacoes();

        System.out.println("\n--- HISTÓRICO DE VENDAS E SERVIÇOS ---");
        if (historicoVendas.isEmpty()) {
            System.out.println("Nenhuma venda ou serviço registrado.");
        } else {
            for (String h : historicoVendas) {
                System.out.println(h);
            }
        }

        System.out.println("\nTotal geral de vendas: R$ " + totalVendas);
        System.out.println("======================================\n");
    }
}
